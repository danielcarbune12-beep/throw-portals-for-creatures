-- BiomeFrozen: Frozen Kingdom, Z [350, 600). Reference: roblox pets/Maps/03_Frozen_Biome.png
-- MAIN: ice citadel on a snowy two-tier plateau with spires, snowflake gate, banners, grand stair (right).
-- SUPPORT: off-lane ice arch over the terraces + crystal ice cave with snowman/sled vignette (left);
--          frozen waterfall into an ice-floe pool beside the citadel.
-- FOREGROUND: snow lane with pale hexagonal ice patches. Distant aurora ribbons on the skyline.
-- Authored as seen in the reference (K.mirror = true: design -X = screen-left).
-- Location: ServerScriptService > Server > BiomeFrozen (ModuleScript)

local K = require(script.Parent.WorldKit)
local V3, CF, ANG, PI, M = K.V3, K.CF, K.ANG, K.PI, K.M
local C = K.C

local B = {}

local ROCK, ROCK_D = C(150, 162, 196), C(112, 124, 164)
local SNOW, ICE, ICE_D, GLOW = C(244, 248, 255), C(196, 228, 250), C(130, 186, 236), C(120, 220, 255)
local BANNER = C(40, 90, 190)

-- flat hexagon made of three rotated slabs
local function hex(pos, r, col, mat, transp)
	for i = 0, 2 do
		K.block(CF(pos) * ANG(0, i * PI / 3, 0), V3(r * 2, 0.1, r * 1.155), col, mat or M.SmoothPlastic, false, transp)
	end
end

local function icicles(cf, w, n)
	for i = 1, n do
		local h = K.r(1, 3)
		K.wedge(cf * CF(K.r(-w / 2, w / 2), -h / 2, 0) * ANG(PI, 0, 0), V3(0.6, h, 0.6), ICE, M.Ice)
	end
end

-- crenellated wall segment along local Z
local function wall(cf, len, h, col)
	K.block(cf * CF(0, h / 2, 0), V3(3, h, len), col, M.Ice, true)
	K.block(cf * CF(0, h + 0.3, 0), V3(3.6, 0.6, len + 0.4), SNOW, M.Snow)
	for z = -len / 2 + 1.5, len / 2 - 1, 3 do K.block(cf * CF(0, h + 1.3, z), V3(3, 1.4, 1.5), col, M.Ice) end
end

-- spired tower: square shaft, snow ledge, glowing window, tall glass spire
local function tower(pos, w, h, spire)
	K.block(CF(pos + V3(0, h / 2, 0)), V3(w, h, w), ICE, M.Ice, true)
	K.block(CF(pos + V3(0, h * 0.35, 0)), V3(w + 0.6, 1, w + 0.6), ICE_D, M.Ice)
	K.block(CF(pos + V3(0, h + 0.5, 0)), V3(w + 1.6, 1, w + 1.6), SNOW, M.Snow)
	for i = 0, 3 do
		local a = i * PI / 2
		K.block(CF(pos + V3(0, h + 1.6, 0)) * ANG(0, a, 0) * CF(0, 0, -(w / 2 + 0.3)), V3(w * 0.3, 1.4, 0.8), ICE, M.Ice)
	end
	K.pyramid(CF(pos + V3(0, h + 1, 0)), w * 0.9, spire or w * 2.2, C(150, 210, 250), M.Glass)
	local win = K.block(CF(pos + V3(-w / 2 - 0.05, h * 0.62, 0)), V3(0.2, h * 0.22, w * 0.3), GLOW, M.Neon, false, 0.2)
	K.tag(win, "TPFC_Glint", { Period = K.r(8, 14) })
end

local function citadel(c)
	-- plateau tiers (snow topped) + crystal veins
	K.block(CF(c.X, -1, c.Z), V3(76, 10, 150), ROCK, M.Slate, true) -- tier A top y 4 (x c-38..c+38)
	K.block(CF(c.X - 0.4, 4.3, c.Z), V3(77, 0.6, 150.4), SNOW, M.Snow)
	K.addSurface(c.X - 38, c.X + 38, c.Z - 75, c.Z + 75, 4.6)
	K.block(CF(c.X + 14, 5, c.Z), V3(48, 14, 110), ROCK_D, M.Slate, true) -- tier B top y 12
	K.block(CF(c.X + 13.6, 12.3, c.Z), V3(49, 0.6, 110.4), SNOW, M.Snow)
	K.addSurface(c.X - 10, c.X + 38, c.Z - 55, c.Z + 55, 12.6)
	icicles(CF(c.X - 10.2, 11.9, c.Z - 30) * ANG(0, PI / 2, 0), 40, 9)
	icicles(CF(c.X - 10.2, 11.9, c.Z + 30) * ANG(0, PI / 2, 0), 40, 9)
	for i = 1, 6 do
		local vein = K.block(CF(c.X - 10.1, K.r(5, 10), c.Z + K.r(-50, 50)) * ANG(K.r(-0.6, 0.6), 0, 0), V3(0.2, K.r(3, 6), 0.5), GLOW, M.Neon, false, 0.1)
		K.tag(vein, "TPFC_Glint", { Period = K.r(9, 16) })
	end
	-- grand stair from tier A up to the gate
	K.stairs(CF(c.X - 15, 4.6, c.Z) * ANG(0, -PI / 2, 0), 14, 7, 1.15, 1.4, SNOW, M.Snow)
	for s = -1, 1, 2 do K.block(CF(c.X - 15, 8, c.Z + s * 7.6), V3(10, 7, 1.2), ICE, M.Ice, true) end
	-- keep: main hall block, gate arch facing the lane, snowflake emblem, banners
	local kx = c.X + 18
	K.block(CF(kx, 12.6 + 11, c.Z), V3(24, 22, 34), ICE, M.Ice, true)
	K.block(CF(kx, 12.6 + 22.4, c.Z), V3(25.6, 0.8, 35.6), SNOW, M.Snow)
	K.gable(CF(kx, 12.6 + 22.8, c.Z) * ANG(0, PI / 2, 0), 24, 9, 34, C(170, 218, 250), M.Glass)
	K.pointedArch(CF(kx - 12.2, 12.6, c.Z) * ANG(0, PI / 2, 0), 9, 10, 6, 1.6, SNOW, M.Snow, GLOW)
	local door = K.block(CF(kx - 12.1, 12.6 + 7, c.Z), V3(0.3, 13, 8.6), C(70, 150, 230), M.Glass, false, 0.2)
	K.lamp(door, GLOW, 30, 1.4)
	for i = 0, 2 do -- snowflake emblem
		K.block(CF(kx - 12.3, 12.6 + 19, c.Z) * ANG(i * PI / 3, 0, 0), V3(0.3, 5, 0.6), C(220, 246, 255), M.Neon)
	end
	for s = -1, 1, 2 do
		local b = K.block(CF(kx - 12.3, 12.6 + 12, c.Z + s * 9), V3(0.3, 10, 3.6), BANNER, M.Fabric)
		K.tag(b, "TPFC_Sway", { Amp = 0.02, Period = 6 })
		K.block(CF(kx - 12.45, 12.6 + 12, c.Z + s * 9) * ANG(PI / 4, 0, 0), V3(0.2, 1.6, 1.6), C(230, 246, 255), M.Neon)
	end
	-- towers: tall central spire + four flankers + walls
	tower(V3(kx + 6, 12.6, c.Z), 10, 34, 26)
	tower(V3(kx - 8, 12.6, c.Z - 22), 7, 24)
	tower(V3(kx - 8, 12.6, c.Z + 22), 7, 24)
	tower(V3(kx + 14, 12.6, c.Z - 34), 8, 28)
	tower(V3(kx + 14, 12.6, c.Z + 34), 8, 28)
	wall(CF(kx - 9, 12.6, c.Z - 42), 30, 8, ICE_D)
	wall(CF(kx - 9, 12.6, c.Z + 42), 30, 8, ICE_D)
	-- frozen waterfall from tier B into an ice-floe pool on tier A
	local fz = c.Z + 56
	K.waterfall(V3(c.X - 10.6, 12.4, fz), 8, 10, PI / 2, C(170, 230, 250), C(235, 248, 255))
	K.block(CF(c.X - 18, 4.45, fz), V3(16, 0.5, 18), C(90, 170, 220), M.Glass, false, 0.2)
	for i = 1, 5 do hex(V3(c.X - 18 + K.r(-6, 6), 4.75, fz + K.r(-7, 7)), K.r(1.2, 2.2), SNOW, M.Snow) end
end

-- big off-lane ice arch standing on the terrace (span along Z, clear of the corridor)
local function iceArch(pos, span)
	local cf = CF(pos) * ANG(0, PI / 2, 0)
	K.arch(cf, span, 10, 5, ICE, M.Ice, nil, nil, 9)
	K.arch(cf * CF(0, 0.6, 0), span + 1, 10.4, 5.6, SNOW, M.Snow, nil, nil, 9) -- snow cap shell (slightly larger)
	icicles(cf * CF(0, 10 + span / 2 - 0.5, 0), span * 0.6, 7)
	for s = -1, 1, 2 do K.crystalCluster(pos + V3(2, 0, s * (span / 2 + 3)), 0.8, { GLOW, ICE }, nil) end
end

-- ice cave: rock mass with a dark mouth and glowing crystals inside, snowman + sled + lantern
local function cave(pos)
	K.block(CF(pos + V3(-8, 8, 0)), V3(20, 16, 26), ROCK, M.Slate, true)
	K.block(CF(pos + V3(-8, 16.4, 0)), V3(21, 1, 27), SNOW, M.Snow)
	K.wedge(CF(pos + V3(2.5, 13, 0)) * ANG(0, -PI / 2, 0), V3(26, 6, 3), ROCK_D, M.Slate)
	K.block(CF(pos + V3(1.9, 5, 0)), V3(0.4, 10, 9), C(20, 30, 60), M.SmoothPlastic)
	K.crystalCluster(pos + V3(1, 0.5, -2), 1.2, { GLOW, C(170, 240, 255) }, 0)
	K.lamp(K.block(CF(pos + V3(3, 3, 0)), V3(0.5, 0.5, 0.5), GLOW, M.Neon, false, 1), GLOW, 22, 1.5)
	-- snowman vignette (environment prop, not a pet)
	local s = pos + V3(8, 0, 9)
	K.block(CF(s + V3(0, 1.8, 0)), V3(3.6, 3.6, 3.6), SNOW, M.Snow, true)
	K.block(CF(s + V3(0, 4.6, 0)), V3(2.7, 2.4, 2.7), SNOW, M.Snow)
	K.block(CF(s + V3(0, 6.8, 0)), V3(2.1, 2.1, 2.1), SNOW, M.Snow)
	K.block(CF(s + V3(0, 5.9, 0)), V3(2.9, 0.5, 2.9), BANNER, M.Fabric)
	K.wedge(CF(s + V3(1.4, 6.8, 0)) * ANG(0, -PI / 2, 0), V3(0.4, 0.4, 1.2), C(255, 140, 40), M.SmoothPlastic)
	K.block(CF(s + V3(0, 8.2, 0)), V3(2.2, 0.8, 2.2), C(70, 50, 40), M.Fabric)
	-- sled + lantern
	local sl = pos + V3(9, 0, -6)
	for k = -1, 1, 2 do K.block(CF(sl + V3(0, 0.25, k * 1.2)), V3(4.6, 0.3, 0.3), C(120, 82, 50), M.Wood) end
	K.block(CF(sl + V3(0, 0.9, 0)), V3(4, 0.4, 2.6), C(150, 104, 64), M.WoodPlanks)
	K.block(CF(sl + V3(-0.4, 1.6, 0)), V3(2.4, 1, 1.8), C(110, 70, 50), M.Fabric)
	K.lantern(sl + V3(3, 0, 2), C(60, 54, 70), C(255, 210, 150), 2.4)
end

function B.Build(b, m)
	K.Seed(3003)
	K.ResetSurfaces()
	K.mirror = true
	local z1, z2 = b[1], b[2]
	K.terraces(z1, z2, {
		rock = ROCK, rockMat = M.Slate, cap = SNOW, capMat = M.Snow, drip = true, tiers = 3,
		h1 = { 2, 4 }, h2 = { 6, 11 }, h3 = { 10, 22 },
		skip = { { 1, 395, 555 } },
		edge = function(p, s)
			if K.chance(0.4) then K.crystal(p + V3(s * 1.5, 0, 0), K.r(2.5, 4), K.r(0.8, 1.2), GLOW, ANG(0, K.r(0, PI), s * 0.3))
			elseif K.chance(0.5) then K.boulder(p + V3(s, 0, 0), 0.7, ROCK, M.Slate, SNOW) end
		end,
	})
	citadel(V3(86, 0, 475))
	-- left: ice arch, cave + vignette, pond, pines
	iceArch(K.at(-66, 400), 18)
	cave(K.at(-62, 560))
	local pond = K.at(-58, 470)
	K.block(CF(pond + V3(0, 0.1, 0)), V3(14, 0.3, 20), C(110, 190, 230), M.Glass, false, 0.15)
	for i = 1, 4 do hex(pond + V3(K.r(-4, 4), 0.32, K.r(-7, 7)), K.r(1, 1.8), SNOW, M.Snow) end
	for i = 1, 16 do
		local x = (i % 2 == 0) and -K.r(56, 100) or K.r(60, 112)
		local z = K.r(z1 + 6, z2 - 6)
		if x < 0 or z < 395 or z > 555 then K.pine(K.at(x, z), K.r(1.1, 1.8), C(44, 104, 80), true) end
	end
	for i = 1, 5 do K.pine(V3(K.r(54, 72), 4.6, K.r(400, 550)), K.r(1, 1.4), C(44, 104, 80), true) end
	-- lane: pale hexagonal ice patches (flush) + a few ice tufts at the edge
	for i = 1, 42 do
		hex(V3(K.r(-28, 28), 0.05, K.r(z1 + 6, z2 - 6)), K.r(2, 4), C(200, 226, 246), M.SmoothPlastic, 0.1)
	end
	for i = 1, 12 do
		local s = i % 2 == 0 and 1 or -1
		K.crystal(V3(s * K.r(39, 43), 0, K.r(z1 + 8, z2 - 8)), K.r(1.6, 2.6), 0.6, ICE_D, ANG(0, K.r(0, PI), s * 0.4))
	end
	-- aurora ribbons on the far skyline (beyond the zone end, high above everything)
	for i = 0, 2 do
		for k = 0, 9 do
			local x = -150 + k * 32
			local seg = K.block(CF(x, 150 + i * 14 + math.sin(k * 0.8 + i) * 10, 720 + i * 30) * ANG(0, 0, math.sin(k * 0.9 + i) * 0.25),
				V3(34, 18, 1), (i == 1) and C(120, 255, 200) or C(90, 230, 255), M.Neon, false, 0.72)
			seg.CastShadow = false
			K.tag(seg, "TPFC_Pulse", { Period = 10 + i * 3, Base = 0.78, Peak = 0.6 })
		end
	end
	-- transition to Crystal: blue mineral veins in deeper rock (z 580..600)
	for s = -1, 1, 2 do
		for i = 1, 3 do
			local p = V3(s * K.r(46, 60), 0, K.r(584, 598))
			K.rockMass(p, K.r(4, 7), K.r(4, 8), K.r(4, 7), C(70, 64, 110), M.Slate, 2)
			K.crystal(p + V3(0, 1, 0), K.r(3, 5), 1, C(150, 120, 255), ANG(0, 0, s * 0.3))
		end
	end
	K.mountains(z1, z2, M.Glacier, 135, 190, 70, 140)
	K.mirror = false
end

return B
